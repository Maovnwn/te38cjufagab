#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#bancetzLaut_
import os, sys


paks = "paks/BL378_Loader-1.0.0-cp39-cp39-linux_aarch64.whl"
config = """
Basic   = {
        "Token"                : "*****",
        "Currency"             : "trx",
        "Reset If Profit"      : 0.00000001,
        "Reset If Lose"        : 0,
        "Reset If Win Streak"  : 1,
        "Reset If Lose Streak" : 0,

        "Target Balance"       : 100,
        "Target Profit"        : 1,
        "Target Lose"          : 0,

        "Auto Change Betset"   : {
                    "Status"               : "ON",
                    "If Win Streak"        : 0,
                    "If Lose Streak"       : 0,
                    "If Profit"            : 0.0001
                    ## "Interval"             : 0
        },

        ## If Profit/Lose Target Reached
        "Re-Play"              : "ON",
        "Refresh Seed"         : "ON",

        # 10 digit/char (fill free)
        # fill with `0` if you want random seed

        "Seed"                 : 0
}

Betset  = [{
        "Name"         : "hiji (1)",
        "Base Bet"     : 0.00003,
        "Max Base Bet" : 0,
        "Chance"       : {
                        "Min": 3.7,
                        "Max": 6
        },

        "HiLo"         : "L",  # AUTO / H / L

        "If Win"       : 1,
        "If Lose"      : 1.057,
        "Number Bets"  : 0,    # Before excecuting Jump Set
        "Jump Status"  : "OFF",
        "Jump Set"     : [{
                "Comment"       : "tuyul",
                "Status"        : "on",
                "Base Bet"      : 0.00000001,
                "Repeat Bets"   : 87,
                "Chance"  : {
                           "Min": 5,
                           "Max": 5
                }},{
                "Comment"       : "tuyulwa",
                "Status"        : "on",
                "Base Bet"      : 0.00000005,
                "Repeat Bets"   : 19,
                "Chance"  : {
                           "Min": 5,
                           "Max": 5
                }},{
                "Comment"       : "tuyulu",
                "Status"        : "on",
                "Base Bet"      : 0.0000001,
                "Repeat Bets"   : 9,
                "Chance"  : {
                           "Min": 5,
                           "Max": 5
                }},{
                "Comment"       : "mainset",
                "Status"        : "on",
                "Base Bet"      : 0.00000015,
                "Repeat Bets"   : 1,
                "Chance"  : {
                           "Min": 5,
                           "Max": 5
                }}
        ]},{
        "Name"         : "dua (2)",
        "Base Bet"     : 0.00003,
        "Max Base Bet" : 0,
        "Chance"       : {
                        "Min": 9,
                        "Max": 11
        },

        "HiLo"         : "H",  # AUTO / H / L

        "If Win"       : 1,
        "If Lose"      : 1.137,
        "Number Bets"  : 0,    # Before excecuting Jump Set
        "Jump Status"  : "OFF",
        "Jump Set"     : [{
                "Comment"       : "tuyul",
                "Status"        : "on",
                "Base Bet"      : 0.00000001,
                "Repeat Bets"   : 87,
                "Chance"  : {
                           "Min": 5,
                           "Max": 5
                }},{
                "Comment"       : "tuyulwa",
                "Status"        : "on",
                "Base Bet"      : 0.00000005,
                "Repeat Bets"   : 19,
                "Chance"  : {
                           "Min": 5,
                           "Max": 5
                }},{
                "Comment"       : "tuyulu",
                "Status"        : "on",
                "Base Bet"      : 0.0000001,
                "Repeat Bets"   : 9,
                "Chance"  : {
                           "Min": 5,
                           "Max": 5
                }},{
                "Comment"       : "mainset",
                "Status"        : "on",
                "Base Bet"      : 0.00000015,
                "Repeat Bets"   : 1,
                "Chance"  : {
                           "Min": 5,
                           "Max": 5
                }}
        ]}
]

Extra   = {

}
#•••••••••••••••••••••••••••••••••••••••••••••••
#  BL`378_project
#  Dice (Stake) v1.0.0 (97)
#  --
#
#  #bancetz.Laut_
#  @ballataxart  (tg)
#  378bancetz.laut@gmail.com
#•••••••••••••••••••••••••••••••••••••••••••••••

"""


try:
    print("\n  \033[93m[!!] Installing module..\033[0m")
    os.system(f"{sys.executable} -m pip install -U --no-cache-dir {paks}")
    print("\n  \033[93m[!!] Writing BLConfig..\033[0m")
    open("BLConfig.py",'w').write(config)
    print("\n  \033[93m[!!] Clean up unused files.\033[0m")
    os.system(f"rm -rf paks setup.py")
    print("\n  \033[93m[!!] OK..\033[0m")
except Exception as e:
    sys.exit(f'\n  \033[91m{e}\033[0m')

